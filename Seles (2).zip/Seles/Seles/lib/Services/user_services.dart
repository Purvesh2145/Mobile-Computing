import 'dart:convert';

import 'package:http/http.dart' as http;
import 'package:seles/Model/user_model.dart';

class ApiService {
  Future<UserResponse> fetchUsers(int page) async {
    final response =
        await http.get(Uri.parse('https://reqres.in/api/users?page=$page'));

    if (response.statusCode == 200) {
      final data = json.decode(response.body);
      return UserResponse.fromJson(data);
    } else {
      throw Exception('Failed to load users');
    }
  }
}
