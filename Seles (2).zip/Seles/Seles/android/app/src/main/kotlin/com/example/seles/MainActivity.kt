package com.example.seles

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
